package grupo01.lostonyetes.androidengine;

import grupo01.lostonyetes.engine.IScene;
import grupo01.lostonyetes.engine.IState;

public class AScene implements IScene, IState {
    @Override
    public void init() {

    }

    @Override
    public void update(double dt) {

    }

    @Override
    public void render() {

    }
}
